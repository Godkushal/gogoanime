<div class="notice-400"
    style=" z-index:99999;position: fixed;bottom: 0;text-align: center;width: 100%; left: 0;padding: 10px;background: #939393;color: white;">
    We moved site to <a href="<?=$base_url?>" title="Gogoanime" alt="Gogoanime" style="color: #ffc119">
        <?=$website_name?>
    </a>. Please bookmark new site. Thank you!
</div>